// SPDX-License-Identifier: AGPL-3.0-or-later
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { ItemType } from '@prisma/client';

import { PrismaService } from '../prisma/prisma.service.js';
import { readV3Layers } from '../data-layer/read-v3-layers.js';
import { KeycloakAdminService } from './keycloak-admin.service.js';
import { KeycloakSyncService } from './keycloak-sync.service.js';
import { DataLayerTablesService } from '../data-layer/tables.service.js';
import { HousekeepingService } from './housekeeping.service.js';
import { NotificationsService } from '../notifications/notifications.service.js';

export type HousekeepingScheduleMode = 'off' | 'daily' | 'weekly';

/**
 * Config the admin form edits. Effective values: any DB-row null
 * resolves to the env default so the UI can show what will actually
 * run without having to know the fallback chain.
 */
export interface HousekeepingConfig {
  autoTrashEnabled: boolean;
  autoTrashDays: number;
  autoDisableEnabled: boolean;
  autoDisableDays: number;
  /** When true, the periodic pass recomputes item.bbox for every
   *  spatial item alongside the trash + disable passes (#93). */
  recomputeExtentsEnabled: boolean;
  /** #276: how many days an empty field-queue manifest can sit idle
   *  before the admin field-queues view hides it by default + the
   *  bulk-forget endpoint considers it stale. */
  fieldQueueStaleDays: number;
  /** #276: when true, the periodic pass deletes empty field-queue
   *  manifest rows older than (fieldQueueStaleDays +
   *  fieldQueueAutoPruneGraceDays). Off by default; admin opts in. */
  fieldQueueAutoPruneEnabled: boolean;
  /** #276: extra cushion past the stale threshold before the cron
   *  actually deletes a row. Defaults so the auto-prune is
   *  conservative. */
  fieldQueueAutoPruneGraceDays: number;
  scheduleMode: HousekeepingScheduleMode;
  scheduleHour: number;
  scheduleMinute: number;
  scheduleDayOfWeek: number | null;
  /** Display-only: plain-English schedule summary. */
  scheduleSummary: string;
  /** Display-only: cron expression the scheduler is actually
   *  registered with, or null when mode='off' or both auto-actions
   *  are disabled (nothing to run). */
  effectiveCron: string | null;
}

export interface HousekeepingConfigPatch {
  autoTrashEnabled?: boolean;
  autoTrashDays?: number | null;
  autoDisableEnabled?: boolean;
  autoDisableDays?: number | null;
  recomputeExtentsEnabled?: boolean;
  fieldQueueStaleDays?: number | null;
  fieldQueueAutoPruneEnabled?: boolean;
  fieldQueueAutoPruneGraceDays?: number | null;
  scheduleMode?: HousekeepingScheduleMode;
  scheduleHour?: number;
  scheduleMinute?: number;
  scheduleDayOfWeek?: number | null;
}

export interface HousekeepingRunResult {
  id: string;
  startedAt: string;
  finishedAt: string | null;
  status: 'running' | 'succeeded' | 'failed';
  trigger: 'manual' | 'scheduled';
  itemsTrashed: number;
  usersDisabled: number;
  error: string | null;
}

/**
 * Owns the singleton HousekeepingConfig row, the auto-action passes,
 * and the HousekeepingRun audit log. Mirrors BackupService's shape so
 * the cron service can subscribe to config changes the same way.
 */
@Injectable()
export class HousekeepingScheduleService {
  private readonly log = new Logger(HousekeepingScheduleService.name);
  private listeners: Array<(cfg: HousekeepingConfig) => void> = [];

  constructor(
    private readonly prisma: PrismaService,
    private readonly cfg: ConfigService,
    private readonly keycloak: KeycloakAdminService,
    private readonly keycloakSync: KeycloakSyncService,
    private readonly dataLayerTables: DataLayerTablesService,
    private readonly housekeeping: HousekeepingService,
    private readonly notifications: NotificationsService,
  ) {}

  // ---------------------------------------------------------------
  // Config
  // ---------------------------------------------------------------

  async getConfig(): Promise<HousekeepingConfig> {
    const row = await this.prisma.housekeepingConfig.findFirst();
    return this.materialize(row);
  }

  async updateConfig(patch: HousekeepingConfigPatch): Promise<HousekeepingConfig> {
    const existing = await this.prisma.housekeepingConfig.findFirst();
    const data: Record<string, unknown> = {};
    if (patch.autoTrashEnabled !== undefined)
      data.autoTrashEnabled = patch.autoTrashEnabled;
    if (patch.autoTrashDays !== undefined)
      data.autoTrashDays = patch.autoTrashDays;
    if (patch.autoDisableEnabled !== undefined)
      data.autoDisableEnabled = patch.autoDisableEnabled;
    if (patch.autoDisableDays !== undefined)
      data.autoDisableDays = patch.autoDisableDays;
    if (patch.recomputeExtentsEnabled !== undefined)
      data.recomputeExtentsEnabled = patch.recomputeExtentsEnabled;
    if (patch.fieldQueueStaleDays !== undefined)
      data.fieldQueueStaleDays = patch.fieldQueueStaleDays;
    if (patch.fieldQueueAutoPruneEnabled !== undefined)
      data.fieldQueueAutoPruneEnabled = patch.fieldQueueAutoPruneEnabled;
    if (patch.fieldQueueAutoPruneGraceDays !== undefined)
      data.fieldQueueAutoPruneGraceDays = patch.fieldQueueAutoPruneGraceDays;
    if (patch.scheduleMode !== undefined)
      data.scheduleMode = patch.scheduleMode;
    if (patch.scheduleHour !== undefined) data.scheduleHour = patch.scheduleHour;
    if (patch.scheduleMinute !== undefined)
      data.scheduleMinute = patch.scheduleMinute;
    if (patch.scheduleDayOfWeek !== undefined)
      data.scheduleDayOfWeek = patch.scheduleDayOfWeek;

    const row = existing
      ? await this.prisma.housekeepingConfig.update({
          where: { id: existing.id },
          data,
        })
      : await this.prisma.housekeepingConfig.create({ data });

    const next = this.materialize(row);
    for (const cb of this.listeners) {
      try {
        cb(next);
      } catch (err) {
        this.log.warn(
          `Config listener threw: ${err instanceof Error ? err.message : err}`,
        );
      }
    }
    return next;
  }

  onConfigChange(cb: (cfg: HousekeepingConfig) => void): void {
    this.listeners.push(cb);
  }

  private envInt(key: string, fallback: number): number {
    const raw = Number(this.cfg.get<string>(key));
    return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : fallback;
  }

  private materialize(
    row: {
      autoTrashEnabled: boolean;
      autoTrashDays: number | null;
      autoDisableEnabled: boolean;
      autoDisableDays: number | null;
      recomputeExtentsEnabled: boolean;
      fieldQueueStaleDays: number | null;
      fieldQueueAutoPruneEnabled: boolean;
      fieldQueueAutoPruneGraceDays: number | null;
      scheduleMode: string;
      scheduleHour: number;
      scheduleMinute: number;
      scheduleDayOfWeek: number | null;
    } | null,
  ): HousekeepingConfig {
    const autoTrashDaysEnv = this.envInt('HOUSEKEEPING_STALE_ITEM_DAYS', 90);
    const autoDisableDaysEnv = this.envInt('HOUSEKEEPING_STALE_USER_DAYS', 180);
    const fieldQueueStaleDaysEnv = this.envInt(
      'HOUSEKEEPING_FIELD_QUEUE_STALE_DAYS',
      7,
    );
    const fieldQueueGraceDaysEnv = this.envInt(
      'HOUSEKEEPING_FIELD_QUEUE_AUTO_PRUNE_GRACE_DAYS',
      90,
    );
    const mode =
      (row?.scheduleMode as HousekeepingScheduleMode | undefined) ?? 'off';
    const hour = row?.scheduleHour ?? 3;
    const minute = row?.scheduleMinute ?? 0;
    const dow = row?.scheduleDayOfWeek ?? null;
    const autoTrash = row?.autoTrashEnabled ?? false;
    const autoDisable = row?.autoDisableEnabled ?? false;
    const recompute = row?.recomputeExtentsEnabled ?? false;
    const fieldQueueAutoPrune = row?.fieldQueueAutoPruneEnabled ?? false;

    let effectiveCron: string | null = null;
    let summary = 'Off';
    if (
      mode !== 'off' &&
      (autoTrash || autoDisable || recompute || fieldQueueAutoPrune)
    ) {
      const m = String(minute).padStart(2, '0');
      const h = String(hour).padStart(2, '0');
      if (mode === 'daily') {
        effectiveCron = `${minute} ${hour} * * *`;
        summary = `Daily at ${h}:${m}`;
      } else if (mode === 'weekly') {
        const d = dow ?? 1;
        effectiveCron = `${minute} ${hour} * * ${d}`;
        const dayName =
          ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d] ?? 'Monday';
        summary = `Weekly on ${dayName} at ${h}:${m}`;
      }
    } else if (
      !autoTrash &&
      !autoDisable &&
      !recompute &&
      !fieldQueueAutoPrune &&
      mode !== 'off'
    ) {
      summary = 'Schedule set, but no auto-actions enabled';
    }

    return {
      autoTrashEnabled: autoTrash,
      autoTrashDays: row?.autoTrashDays ?? autoTrashDaysEnv,
      autoDisableEnabled: autoDisable,
      autoDisableDays: row?.autoDisableDays ?? autoDisableDaysEnv,
      recomputeExtentsEnabled: recompute,
      fieldQueueStaleDays:
        row?.fieldQueueStaleDays ?? fieldQueueStaleDaysEnv,
      fieldQueueAutoPruneEnabled: fieldQueueAutoPrune,
      fieldQueueAutoPruneGraceDays:
        row?.fieldQueueAutoPruneGraceDays ?? fieldQueueGraceDaysEnv,
      scheduleMode: mode,
      scheduleHour: hour,
      scheduleMinute: minute,
      scheduleDayOfWeek: dow,
      scheduleSummary: summary,
      effectiveCron,
    };
  }

  // ---------------------------------------------------------------
  // Run pass: auto-trash + auto-disable
  // ---------------------------------------------------------------

  async runOnce(args: {
    trigger: 'manual' | 'scheduled';
    startedBy: string | null;
  }): Promise<HousekeepingRunResult> {
    const cfg = await this.getConfig();
    const run = await this.prisma.housekeepingRun.create({
      data: {
        trigger: args.trigger,
        startedBy: args.startedBy,
        status: 'running',
      },
    });
    let itemsTrashed = 0;
    let usersDisabled = 0;
    let error: string | null = null;
    try {
      if (cfg.autoTrashEnabled) {
        itemsTrashed = await this.autoTrashStaleItems(cfg.autoTrashDays);
      }
      if (cfg.autoDisableEnabled) {
        usersDisabled = await this.autoDisableQuietUsers(cfg.autoDisableDays);
      }
      // Auto-disable for users with an explicit auto_disable_at in
      // the past (#85/#86). Runs unconditionally: the admin set an
      // explicit end date per-user, so this isn't gated by the
      // quiet-user heuristic toggle. Counts roll into usersDisabled
      // for the audit log so "X users disabled" stays one number;
      // logger output below distinguishes the cause.
      const expired = await this.autoDisableExpiredUsers();
      usersDisabled += expired;
      // Optional periodic recompute-extents (#93). Loops every org
      // and recomputes their spatial item bboxes. Cheap for a
      // typical pure-data_layer org; with arcgis services it does
      // N HTTP probes so the toggle is explicit-opt-in. Failures
      // on a single org are logged and we move on; one bad org
      // can't black out the whole sweep.
      if (cfg.recomputeExtentsEnabled) {
        const orgs = await this.prisma.organization.findMany({
          select: { id: true, slug: true },
        });
        for (const org of orgs) {
          try {
            const result = await this.housekeeping.recomputeExtents(org.id);
            this.log.log(
              `recompute-extents (${org.slug}): ${result.updated}/${result.scanned} items refreshed`,
            );
          } catch (err) {
            this.log.warn(
              `recompute-extents failed for org ${org.slug}: ${
                err instanceof Error ? err.message : err
              }`,
            );
          }
        }
      }
      // #276: auto-prune stale field-queue manifests. Deletes rows
      // whose manifest is empty AND whose last beacon is older than
      // (staleDays + graceDays). Off by default; admin opts in.
      // Deliberately conservative -- a row with non-empty queue is
      // signal even if silent, and the grace window ensures we
      // don't delete a row a worker could still come back to.
      if (cfg.fieldQueueAutoPruneEnabled) {
        const totalDays =
          cfg.fieldQueueStaleDays + cfg.fieldQueueAutoPruneGraceDays;
        const cutoff = new Date(Date.now() - totalDays * 24 * 60 * 60 * 1000);
        const candidates = await this.prisma.fieldQueueManifest.findMany({
          where: { reportedAt: { lt: cutoff } },
          select: { id: true, manifest: true },
        });
        const stale = candidates.filter((r) => {
          const m = (r.manifest as Array<{
            queuedRecords?: Array<unknown>;
          }> | null) ?? [];
          return m.every(
            (entry) => (entry.queuedRecords?.length ?? 0) === 0,
          );
        });
        if (stale.length > 0) {
          const result = await this.prisma.fieldQueueManifest.deleteMany({
            where: { id: { in: stale.map((r) => r.id) } },
          });
          this.log.log(
            `field-queue-auto-prune: deleted ${result.count} manifests (cutoff ${totalDays}d)`,
          );
        }
      }
      // Keycloak -> Prisma user mirror reconcile. Runs unconditionally
      // (not gated on a config toggle) because the cost is a single
      // realm scan per cron tick and an out-of-sync mirror surfaces
      // as ghost / missing users in the principal picker -- a class
      // of bug the eager pass exists to prevent. Self-skips when
      // Keycloak admin isn't configured. Failures don't abort the
      // run; the picker just stays as fresh as the previous tick.
      try {
        const summary = await this.keycloakSync.reconcileAll();
        if (!summary.skipped) {
          this.log.log(
            `keycloak-sync: realmUsers=${summary.realmUsersSeen} inserted=${summary.inserted} updated=${summary.updated} softDeleted=${summary.softDeleted}`,
          );
        }
      } catch (err) {
        this.log.warn(
          `keycloak-sync threw inside runOnce: ${
            err instanceof Error ? err.message : err
          }`,
        );
      }
      const finished = await this.prisma.housekeepingRun.update({
        where: { id: run.id },
        data: {
          status: 'succeeded',
          finishedAt: new Date(),
          itemsTrashed,
          usersDisabled,
        },
      });
      return this.toResult(finished);
    } catch (e) {
      error = (e as Error).message ?? String(e);
      const finished = await this.prisma.housekeepingRun.update({
        where: { id: run.id },
        data: {
          status: 'failed',
          finishedAt: new Date(),
          itemsTrashed,
          usersDisabled,
          error: error.slice(0, 500),
        },
      });
      this.log.error(
        `Housekeeping run ${run.id} failed: ${error}`,
      );
      return this.toResult(finished);
    }
  }

  /**
   * Soft-delete every item that matches the stale-item heuristic
   * from HousekeepingService.staleItems (no recent edits, zero
   * shares). Item soft-delete is reversible from the trash, so
   * accidental over-trashing is recoverable.
   *
   * Per #95, "no recent edits" must include underlying feature
   * activity, not just item.updatedAt: a data_layer with active
   * feature edits is fresh even when nobody touched the item card.
   * We pull candidates by item.updatedAt then filter out anything
   * whose v3 layer tables show recent activity before trashing.
   */
  private async autoTrashStaleItems(days: number): Promise<number> {
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const candidates = await this.prisma.item.findMany({
      where: {
        deletedAt: null,
        updatedAt: { lt: cutoff },
        // Mirror staleItems(): an item recently hit through the
        // proxy can't be auto-trashed regardless of how stale the
        // item card looks. NULL lastUsageAt means "never used via
        // proxy"; the per-item refine still applies.
        OR: [{ lastUsageAt: null }, { lastUsageAt: { lt: cutoff } }],
        shares: { none: {} },
      },
      select: {
        id: true,
        orgId: true,
        type: true,
        data: true,
        updatedAt: true,
        lastUsageAt: true,
      },
    });
    // Build referenced-set per org so an item depended-on by any
    // non-trashed sibling stays alive (#98). Cached across the
    // candidate loop because a single org typically owns many
    // candidates and the helper does one query per org.
    const referencedByOrg = new Map<string, Set<string>>();
    const refSetFor = async (orgId: string): Promise<Set<string>> => {
      const cached = referencedByOrg.get(orgId);
      if (cached) return cached;
      const set = await this.housekeeping.buildReferencedItemSet(orgId);
      referencedByOrg.set(orgId, set);
      return set;
    };
    const toTrash: string[] = [];
    for (const c of candidates) {
      const referenced = await refSetFor(c.orgId);
      if (referenced.has(c.id)) continue;
      const dataAt = await this.dataActivityAt(c.id, c.type, c.data);
      let effective = c.updatedAt;
      if (dataAt && dataAt > effective) effective = dataAt;
      if (c.lastUsageAt && c.lastUsageAt > effective) effective = c.lastUsageAt;
      if (effective < cutoff) toTrash.push(c.id);
    }
    if (toTrash.length === 0) return 0;
    const res = await this.prisma.item.updateMany({
      where: { id: { in: toTrash } },
      data: { deletedAt: new Date() },
    });
    return res.count;
  }

  /**
   * Most recent feature-level activity for a v3 data_layer; null
   * for other types (caller falls back to item.updatedAt).
   * Mirrors HousekeepingService.dataActivityAt; duplicated here so
   * the auto-trash path doesn't need to depend on the analytics
   * service.
   */
  private async dataActivityAt(
    itemId: string,
    type: ItemType,
    data: unknown,
  ): Promise<Date | null> {
    if (type !== 'data_layer') return null;
    const layers = readV3Layers(data);
    if (layers === null || layers.length === 0) return null;
    return this.dataLayerTables.lastDataActivityAt(itemId, layers);
  }

  /**
   * Disable sign-in for users whose explicit auto_disable_at is in
   * the past (#85/#86). Always runs in the housekeeping pass, even
   * when the quiet-user heuristic is off: the admin set a hard end
   * date per-user, and that contract should hold whether or not
   * `autoDisableEnabled` is checked. Keycloak's `enabled=false` is
   * idempotent so re-running the same user is harmless.
   *
   * auth-sync rejects the request with 401 the moment the timestamp
   * passes (see auth-sync.service.ts), so this cron is the second
   * half of a belt-and-braces gate: Keycloak's enabled flag stops
   * the SSO refresh-token loop from minting fresh JWTs.
   */
  private async autoDisableExpiredUsers(): Promise<number> {
    const candidates = await this.prisma.user.findMany({
      where: {
        orgRole: { not: 'admin' },
        autoDisableAt: { not: null, lte: new Date() },
      },
      select: { id: true, username: true, autoDisableAt: true },
    });
    let count = 0;
    for (const u of candidates) {
      try {
        // Resolve the Keycloak id from the username: u.id is the local
        // row id, which differs from the Keycloak sub for seeded /
        // pre-Keycloak users, so updateUser(u.id) would 404 and the
        // disable would silently never happen.
        const kcId = await this.keycloak.findUserIdByUsername(u.username);
        if (!kcId) {
          this.log.warn(
            `auto-disable (expired): no Keycloak user for ${u.username}; skipping`,
          );
          continue;
        }
        await this.keycloak.updateUser(kcId, { enabled: false });
        count += 1;
        // Fire user_disabled notification (#128). The cron's
        // sweep-once-per-tick contract means we only get here when
        // the row freshly crossed the threshold or the previous
        // tick failed; the notify() path is idempotent on
        // (userId, type, autoDisableAt) so a flap doesn't double-
        // email. Fire-and-forget: a notify failure shouldn't
        // unflip the Keycloak disable.
        if (u.autoDisableAt) {
          void this.notifications.notify(u.id, 'user_disabled', {
            autoDisableAt: u.autoDisableAt.toISOString(),
          });
        }
      } catch (err) {
        this.log.warn(
          `auto-disable (expired): could not disable ${u.username} (${u.id}): ${
            err instanceof Error ? err.message : err
          }`,
        );
      }
    }
    if (count > 0) {
      this.log.log(
        `auto-disable (expired): flipped Keycloak enabled=false on ${count} user(s).`,
      );
    }
    return count;
  }

  /**
   * Disable sign-in for users matching the quiet-user heuristic.
   * Per CLAUDE.md / the housekeeping page, admins are exempt
   * (break-glass accounts may legitimately be idle). Disable runs
   * through Keycloak so the SSO flow rejects the next login;
   * the local user row stays put for ownership integrity.
   *
   * Best-effort: a Keycloak failure on one user does not abort the
   * whole pass. We log and continue, so a flaky network doesn't
   * leave the run half-done.
   */
  private async autoDisableQuietUsers(days: number): Promise<number> {
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    const candidates = await this.prisma.user.findMany({
      where: {
        orgRole: { not: 'admin' },
        OR: [
          { lastSeenAt: { lt: cutoff } },
          { AND: [{ lastSeenAt: null }, { createdAt: { lt: cutoff } }] },
        ],
      },
      select: { id: true, username: true },
    });
    let count = 0;
    const now = new Date();
    for (const u of candidates) {
      try {
        // See autoDisableExpiredUsers: resolve the Keycloak id by
        // username, since u.id is the local row id and would 404 for
        // seeded users.
        const kcId = await this.keycloak.findUserIdByUsername(u.username);
        if (!kcId) {
          this.log.warn(
            `auto-disable: no Keycloak user for ${u.username}; skipping`,
          );
          continue;
        }
        await this.keycloak.updateUser(kcId, { enabled: false });
        count += 1;
        // Quiet-user disable doesn't have a stored autoDisableAt
        // (the heuristic is the disable trigger). Use `now` as
        // the synthetic timestamp so the user sees a real "your
        // account was disabled on <today>" message; the
        // notification's idempotency key falls back to user_id +
        // type if the autoDisableAt timestamp matches.
        void this.notifications.notify(u.id, 'user_disabled', {
          autoDisableAt: now.toISOString(),
        });
      } catch (err) {
        this.log.warn(
          `auto-disable: could not disable ${u.username} (${u.id}): ${
            err instanceof Error ? err.message : err
          }`,
        );
      }
    }
    return count;
  }

  // ---------------------------------------------------------------
  // Run history
  // ---------------------------------------------------------------

  async listRuns(limit = 25): Promise<HousekeepingRunResult[]> {
    const rows = await this.prisma.housekeepingRun.findMany({
      orderBy: { startedAt: 'desc' },
      take: Math.min(Math.max(1, limit), 200),
    });
    return rows.map((r) => this.toResult(r));
  }

  private toResult(r: {
    id: string;
    startedAt: Date;
    finishedAt: Date | null;
    status: 'running' | 'succeeded' | 'failed';
    trigger: string;
    itemsTrashed: number;
    usersDisabled: number;
    error: string | null;
  }): HousekeepingRunResult {
    return {
      id: r.id,
      startedAt: r.startedAt.toISOString(),
      finishedAt: r.finishedAt?.toISOString() ?? null,
      status: r.status,
      trigger:
        r.trigger === 'scheduled' ? 'scheduled' : 'manual',
      itemsTrashed: r.itemsTrashed,
      usersDisabled: r.usersDisabled,
      error: r.error,
    };
  }
}
