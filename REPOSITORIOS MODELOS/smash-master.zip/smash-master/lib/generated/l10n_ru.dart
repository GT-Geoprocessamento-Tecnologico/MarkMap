// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'l10n.dart';

// ignore_for_file: type=lint

/// The translations for Russian (`ru`).
class SLRu extends SL {
  SLRu([String locale = 'ru']) : super(locale);

  @override
  String get main_welcome => 'Добро пожаловать в SMASH!';

  @override
  String get main_check_location_permission => 'Checking location permission…';

  @override
  String get main_location_permission_granted => 'Location permission granted.';

  @override
  String get main_checkingStoragePermission => 'Checking storage permission…';

  @override
  String get main_storagePermissionGranted => 'Storage permission granted.';

  @override
  String get main_loadingPreferences => 'Loading preferences…';

  @override
  String get main_preferencesLoaded => 'Preferences loaded.';

  @override
  String get main_loadingWorkspace => 'Loading workspace…';

  @override
  String get main_workspaceLoaded => 'Workspace loaded.';

  @override
  String get main_loadingTagsList => 'Loading tags list…';

  @override
  String get main_tagsListLoaded => 'Tags list loaded.';

  @override
  String get main_loadingKnownProjections => 'Loading known projections…';

  @override
  String get main_knownProjectionsLoaded => 'Known projections loaded.';

  @override
  String get main_loadingFences => 'Loading fences…';

  @override
  String get main_fencesLoaded => 'Fences loaded.';

  @override
  String get main_loadingLayersList => 'Loading layers list…';

  @override
  String get main_layersListLoaded => 'Layers list loaded.';

  @override
  String get main_locationBackgroundWarning =>
      'Grant location permission in the next step to allow GPS logging in the background. (Otherwise it only works in the foreground.)\nNo data is shared, and only saved locally on the device.';

  @override
  String get main_StorageIsInternalWarning =>
      'Please read carefully!\nOn Android 11 and above, the SMASH project folder must be placed in the\n\nAndroid/data/eu.hydrologis.smash/files/smash\n\nfolder in your storage to be used.\nIf the app is uninstalled, the system removes it, so back up your data if you do.\n\nA better solution is in the works.';

  @override
  String get main_locationPermissionIsMandatoryToOpenSmash =>
      'Location permission is mandatory to open SMASH.';

  @override
  String get main_storagePermissionIsMandatoryToOpenSmash =>
      'Storage permission is mandatory to open SMASH.';

  @override
  String get main_anErrorOccurredTapToView => 'An error occurred. Tap to view.';

  @override
  String get mainView_loadingData => 'Загрузка данных…';

  @override
  String get mainView_turnGpsOn => 'Turn GPS on';

  @override
  String get mainView_turnGpsOff => 'Turn GPS off';

  @override
  String get mainView_exit => 'Выход';

  @override
  String get mainView_areYouSureCloseTheProject => 'Close the project?';

  @override
  String get mainView_activeOperationsWillBeStopped =>
      'Active operations will be stopped.';

  @override
  String get mainView_showInteractiveCoachMarks =>
      'Show interactive coach marks.';

  @override
  String get mainView_openToolsDrawer => 'Open tools drawer.';

  @override
  String get mainView_zoomIn => 'Приблизить';

  @override
  String get mainView_zoomOut => 'Отдалить';

  @override
  String get mainView_formNotes => 'Form Notes';

  @override
  String get mainView_simpleNotes => 'Simple Notes';

  @override
  String get mainviewUtils_projects => 'Проекты';

  @override
  String get mainviewUtils_import => 'Импорт';

  @override
  String get mainviewUtils_export => 'Экспорт';

  @override
  String get mainviewUtils_settings => 'Настройки';

  @override
  String get mainviewUtils_onlineHelp => 'Онлайн-помощь';

  @override
  String get mainviewUtils_about => 'О приложении';

  @override
  String get mainviewUtils_projectInfo => 'Информация о проекте';

  @override
  String get mainviewUtils_projectStats => 'Project Stats';

  @override
  String get mainviewUtils_project => 'Проект';

  @override
  String get mainviewUtils_database => 'База данных';

  @override
  String get mainviewUtils_extras => 'Extras';

  @override
  String get mainviewUtils_availableIcons => 'Available icons';

  @override
  String get mainviewUtils_offlineMaps => 'Офлайн-карты';

  @override
  String get mainviewUtils_positionTools => 'Position Tools';

  @override
  String get mainviewUtils_goTo => 'Перейти к';

  @override
  String get mainviewUtils_goToCoordinate => 'Go to coordinate';

  @override
  String get mainviewUtils_enterLonLat => 'Enter longitude, latitude';

  @override
  String get mainviewUtils_goToCoordinateWrongFormat =>
      'Wrong coordinate format. Should be: 11.18463, 46.12345';

  @override
  String get mainviewUtils_goToCoordinateEmpty => 'This can\'t be empty.';

  @override
  String get mainviewUtils_sharePosition => 'Поделиться позицией';

  @override
  String get mainviewUtils_rotateMapWithGps => 'Rotate map with GPS';

  @override
  String get exportWidget_export => 'Экспорт';

  @override
  String get exportWidget_pdfExported => 'PDF exported';

  @override
  String get exportWidget_exportToPortableDocumentFormat =>
      'Export project to Portable Document Format';

  @override
  String get exportWidget_gpxExported => 'GPX exported';

  @override
  String get exportWidget_exportToGpx => 'Export project to GPX';

  @override
  String get exportWidget_kmlExported => 'KML exported';

  @override
  String get exportWidget_exportToKml => 'Export project to KML';

  @override
  String get exportWidget_imagesToFolderExported => 'Images exported';

  @override
  String get exportWidget_exportImagesToFolder =>
      'Export project images to folder';

  @override
  String get exportWidget_exportImagesToFolderTitle => 'Изображения';

  @override
  String get exportWidget_geopackageExported => 'Geopackage exported';

  @override
  String get exportWidget_exportToGeopackage => 'Export project to Geopackage';

  @override
  String get exportWidget_exportToGSS => 'Export to Geopaparazzi Survey Server';

  @override
  String get gssExport_gssExport => 'Экспорт GSS';

  @override
  String get gssExport_setProjectDirty => 'Set project to DIRTY?';

  @override
  String get gssExport_thisCantBeUndone => 'This can\'t be undone!';

  @override
  String get gssExport_restoreProjectAsDirty => 'Restore project as all dirty.';

  @override
  String get gssExport_setProjectClean => 'Set project to CLEAN?';

  @override
  String get gssExport_restoreProjectAsClean => 'Restore project as all clean.';

  @override
  String get gssExport_nothingToSync => 'Nothing to sync.';

  @override
  String get gssExport_collectingSyncStats => 'Collecting sync stats…';

  @override
  String get gssExport_unableToSyncDueToError =>
      'Unable to sync due to an error, check diagnostics.';

  @override
  String get gssExport_noGssUrlSet =>
      'No GSS server URL has been set. Check your settings.';

  @override
  String get gssExport_noGssPasswordSet =>
      'No GSS server password has been set. Check your settings.';

  @override
  String get gssExport_synStats => 'Sync Stats';

  @override
  String get gssExport_followingDataWillBeUploaded =>
      'The following data will be uploaded upon sync.';

  @override
  String get gssExport_gpsLogs => 'GPS Logs:';

  @override
  String get gssExport_simpleNotes => 'Simple Notes:';

  @override
  String get gssExport_formNotes => 'Form Notes:';

  @override
  String get gssExport_images => 'Изображения:';

  @override
  String get gssExport_shouldNotHappen => 'Should not happen';

  @override
  String get gssExport_upload => 'Upload';

  @override
  String get geocoding_geocoding => 'Геокодирование';

  @override
  String get geocoding_nothingToLookFor =>
      'Nothing to look for. Insert an address.';

  @override
  String get geocoding_launchGeocoding => 'Запустите геокодирование';

  @override
  String get geocoding_searching => 'Поиск…';

  @override
  String get gps_smashIsActive => 'SMASH is active';

  @override
  String get gps_smashIsLogging => 'SMASH is logging';

  @override
  String get gps_locationTracking => 'Отслеживание местоположения';

  @override
  String get gps_smashLocServiceIsActive => 'SMASH location service is active.';

  @override
  String get gps_backgroundLocIsOnToKeepRegistering =>
      'Background location is on to keep the app registering the location even when the app is in background.';

  @override
  String get gssImport_gssImport => 'Импорт GSS';

  @override
  String get gssImport_downloadingDataList => 'Downloading data list…';

  @override
  String get gssImport_unableDownloadDataList =>
      'Unable to download data list due to an error. Check your settings and the log.';

  @override
  String get gssImport_noGssUrlSet =>
      'No GSS server URL has been set. Check your settings.';

  @override
  String get gssImport_noGssPasswordSet =>
      'No GSS server password has been set. Check your settings.';

  @override
  String get gssImport_noPermToAccessServer =>
      'No permission to access the server. Check your credentials.';

  @override
  String get gssImport_data => 'Данные';

  @override
  String get gssImport_dataSetsDownloadedMapsFolder =>
      'Datasets are downloaded into the maps folder.';

  @override
  String get gssImport_noDataAvailable => 'No data available.';

  @override
  String get gssImport_projects => 'Проекты';

  @override
  String get gssImport_projectsDownloadedProjectFolder =>
      'Projects are downloaded into the projects folder.';

  @override
  String get gssImport_noProjectsAvailable => 'No projects available.';

  @override
  String get gssImport_forms => 'Forms';

  @override
  String get gssImport_tagsDownloadedFormsFolder =>
      'Tags files are downloaded into the forms folder.';

  @override
  String get gssImport_noTagsAvailable => 'No tags available.';

  @override
  String get importWidget_import => 'Импорт';

  @override
  String get importWidget_importFromGeopaparazzi =>
      'Import from Geopaparazzi Survey Server';

  @override
  String get layersView_layerList => 'Список слоев';

  @override
  String get layersView_loadRemoteDatabase => 'Load remote database';

  @override
  String get layersView_loadOnlineSources => 'Load online sources';

  @override
  String get layersView_loadLocalDatasets => 'Load local datasets';

  @override
  String get layersView_loading => 'Загрузка…';

  @override
  String get layersView_zoomTo => 'Zoom to';

  @override
  String get layersView_properties => 'Свойства';

  @override
  String get layersView_delete => 'Удалить';

  @override
  String get layersView_projCouldNotBeRecognized =>
      'The proj could not be recognised. Tap to enter epsg manually.';

  @override
  String get layersView_projNotSupported =>
      'The proj is not supported. Tap to solve.';

  @override
  String get layersView_onlyImageFilesWithWorldDef =>
      'Only image files with world file definition are supported.';

  @override
  String get layersView_onlyImageFileWithPrjDef =>
      'Only image files with prj file definition are supported.';

  @override
  String get layersView_selectTableToLoad => 'Select table to load.';

  @override
  String get layersView_fileFormatNotSUpported => 'File format not supported.';

  @override
  String get onlineSourcesPage_onlineSourcesCatalog => 'Online Sources Catalog';

  @override
  String get onlineSourcesPage_loadingTmsLayers => 'Loading TMS layers…';

  @override
  String get onlineSourcesPage_loadingWmsLayers => 'Loading WMS layers…';

  @override
  String get onlineSourcesPage_importFromFile => 'Import from file';

  @override
  String get onlineSourcesPage_theFile => 'The file';

  @override
  String get onlineSourcesPage_doesntExist => 'doesn\'t exist';

  @override
  String get onlineSourcesPage_onlineSourcesImported =>
      'Online sources imported.';

  @override
  String get onlineSourcesPage_exportToFile => 'Export to file';

  @override
  String get onlineSourcesPage_exportedTo => 'Экспортировано в:';

  @override
  String get onlineSourcesPage_delete => 'Удалить';

  @override
  String get onlineSourcesPage_addToLayers => 'Add to layers';

  @override
  String get onlineSourcesPage_setNameTmsService =>
      'Set a name for the TMS service';

  @override
  String get onlineSourcesPage_enterName => 'введите имя';

  @override
  String get onlineSourcesPage_pleaseEnterValidName =>
      'Please enter a valid name';

  @override
  String get onlineSourcesPage_insertUrlOfService =>
      'Insert the URL of the service.';

  @override
  String get onlineSourcesPage_placeXyzBetBrackets =>
      'Place the x, y, z between curly brackets.';

  @override
  String get onlineSourcesPage_pleaseEnterValidTmsUrl =>
      'Please enter a valid TMS URL';

  @override
  String get onlineSourcesPage_enterUrl => 'введите URL-адрес';

  @override
  String get onlineSourcesPage_enterSubDomains => 'enter subdomains';

  @override
  String get onlineSourcesPage_addAttribution => 'Add an attribution.';

  @override
  String get onlineSourcesPage_enterAttribution => 'enter attribution';

  @override
  String get onlineSourcesPage_setMinMaxZoom => 'Set min and max zoom.';

  @override
  String get onlineSourcesPage_minZoom => 'Min zoom';

  @override
  String get onlineSourcesPage_maxZoom => 'Max zoom';

  @override
  String get onlineSourcesPage_pleaseCheckYourData => 'Please check your data';

  @override
  String get onlineSourcesPage_details => 'Подробности';

  @override
  String get onlineSourcesPage_name => 'Название: ';

  @override
  String get onlineSourcesPage_subDomains => 'Поддомены: ';

  @override
  String get onlineSourcesPage_attribution => 'Attribution: ';

  @override
  String get onlineSourcesPage_cancel => 'Отмена';

  @override
  String get onlineSourcesPage_ok => 'ОК';

  @override
  String get onlineSourcesPage_newTmsOnlineService => 'New TMS Online Service';

  @override
  String get onlineSourcesPage_save => 'Сохранить';

  @override
  String get onlineSourcesPage_theBaseUrlWithQuestionMark =>
      'The base URL-ending with question mark.';

  @override
  String get onlineSourcesPage_pleaseEnterValidWmsUrl =>
      'Please enter a valid WMS URL';

  @override
  String get onlineSourcesPage_setWmsLayerName => 'Set WMS layer name';

  @override
  String get onlineSourcesPage_enterLayerToLoad => 'enter layer to load';

  @override
  String get onlineSourcesPage_pleaseEnterValidLayer =>
      'Please enter a valid layer';

  @override
  String get onlineSourcesPage_setWmsImageFormat => 'Set WMS image format';

  @override
  String get onlineSourcesPage_addAnAttribution => 'Add an attribution.';

  @override
  String get onlineSourcesPage_layer => 'Слой: ';

  @override
  String get onlineSourcesPage_url => 'URL: ';

  @override
  String get onlineSourcesPage_format => 'Формат';

  @override
  String get onlineSourcesPage_newWmsOnlineService => 'New WMS Online Service';

  @override
  String get remoteDbPage_remoteDatabases => 'Удаленные базы данных';

  @override
  String get remoteDbPage_delete => 'Удалить';

  @override
  String get remoteDbPage_areYouSureDeleteDatabase =>
      'Delete the database configuration?';

  @override
  String get remoteDbPage_edit => 'Редактировать';

  @override
  String get remoteDbPage_duplicate => 'Duplicate';

  @override
  String get remoteDbPage_table => 'table';

  @override
  String get remoteDbPage_user => 'пользователь';

  @override
  String get remoteDbPage_loadInMap => 'Load in map.';

  @override
  String get remoteDbPage_databaseParameters => 'Параметры базы данных';

  @override
  String get remoteDbPage_cancel => 'Отмена';

  @override
  String get remoteDbPage_ok => 'ОК';

  @override
  String get remoteDbPage_theUrlNeedsToBeDefined =>
      'The URL must be defined (postgis:host:port/databasename)';

  @override
  String get remoteDbPage_theUserNeedsToBeDefined => 'A user must be defined.';

  @override
  String get remoteDbPage_password => 'пароль';

  @override
  String get remoteDbPage_thePasswordNeedsToBeDefined =>
      'A password must be defined.';

  @override
  String get remoteDbPage_loadingTables => 'Loading tables…';

  @override
  String get remoteDbPage_theTableNeedsToBeDefined =>
      'The table name must be defined.';

  @override
  String get remoteDbPage_unableToConnectToDatabase =>
      'Unable to connect to the database. Check parameters and network.';

  @override
  String get remoteDbPage_optionalWhereCondition =>
      'optional \"where\" condition';

  @override
  String get geoImage_tiffProperties => 'Свойства TIFF';

  @override
  String get geoImage_opacity => 'Непрозрачность';

  @override
  String get geoImage_colorToHide => 'Color to hide';

  @override
  String get gpx_gpxProperties => 'Свойства GPX';

  @override
  String get gpx_wayPoints => 'Путевые точки';

  @override
  String get gpx_color => 'Цвет';

  @override
  String get gpx_size => 'Размер';

  @override
  String get gpx_viewLabelsIfAvailable => 'View labels if available?';

  @override
  String get gpx_tracksRoutes => 'Tracks/routes';

  @override
  String get gpx_width => 'Width';

  @override
  String get gpx_palette => 'Палитра';

  @override
  String get tiles_tileProperties => 'Tile Properties';

  @override
  String get tiles_opacity => 'Непрозрачность';

  @override
  String get tiles_loadGeoPackageAsOverlay =>
      'Load geopackage tiles as overlay image as opposed to tile layer (best for gdal generated data and different projections).';

  @override
  String get tiles_colorToHide => 'Color to hide';

  @override
  String get wms_wmsProperties => 'Свойства WMS';

  @override
  String get wms_opacity => 'Непрозрачность';

  @override
  String get featureAttributesViewer_loadingData => 'Загрузка данных…';

  @override
  String get featureAttributesViewer_setNewValue => 'Set new value';

  @override
  String get featureAttributesViewer_field => 'Поле';

  @override
  String get featureAttributesViewer_value => 'ЗНАЧЕНИЕ';

  @override
  String get projectsView_projectsView => 'Просмотр проектов';

  @override
  String get projectsView_openExistingProject => 'Открыть существующий проект';

  @override
  String get projectsView_createNewProject => 'Создать новый проект';

  @override
  String get projectsView_recentProjects => 'Последние проекты';

  @override
  String get projectsView_newProject => 'Новый проект';

  @override
  String get projectsView_enterNameForNewProject =>
      'Введите название для нового проекта или примите предложенное.';

  @override
  String get dataLoader_note => 'примечание';

  @override
  String get dataLoader_Note => 'Примечание';

  @override
  String get dataLoader_hasForm => 'Has Form';

  @override
  String get dataLoader_POI => 'POI';

  @override
  String get dataLoader_savingImageToDB => 'Saving image to database…';

  @override
  String get dataLoader_removeNote => 'Удалить заметку';

  @override
  String get dataLoader_areYouSureRemoveNote => 'Удалить заметку?';

  @override
  String get dataLoader_image => 'Изображение';

  @override
  String get dataLoader_longitude => 'Долгота';

  @override
  String get dataLoader_latitude => 'Широта';

  @override
  String get dataLoader_altitude => 'Высота';

  @override
  String get dataLoader_timestamp => 'Временная метка';

  @override
  String get dataLoader_removeImage => 'Удалить изображение';

  @override
  String get dataLoader_areYouSureRemoveImage => 'Remove the image?';

  @override
  String get images_loadingImage => 'Загрузка изображения…';

  @override
  String get about_loadingInformation => 'Загрузка информации…';

  @override
  String get about_ABOUT => 'О программе ';

  @override
  String get about_smartMobileAppForSurveyor =>
      'Smart Mobile App for Surveyor Happiness';

  @override
  String get about_applicationVersion => 'Версия';

  @override
  String get about_license => 'Лицензия';

  @override
  String get about_isAvailableUnderGPL3 =>
      ' is copylefted libre software, licensed GPLv3+.';

  @override
  String get about_sourceCode => 'Исходный код';

  @override
  String get about_tapHereToVisitRepo =>
      'Tap here to visit the source code repository';

  @override
  String get about_legalInformation => 'Юридическая информация';

  @override
  String get about_copyright2020HydroloGIS =>
      'Copyright © 2020, HydroloGIS S.r.l. — some rights reserved. Tap to visit.';

  @override
  String get about_supportedBy => 'При поддержке';

  @override
  String get about_partiallySupportedByUniversityTrento =>
      'Partially supported by the project Steep Stream of the University of Trento.';

  @override
  String get about_privacyPolicy => 'Политика конфиденциальности';

  @override
  String get about_tapHereToSeePrivacyPolicy =>
      'Tap here to see the privacy policy that covers user and location data.';

  @override
  String get gpsInfoButton_noGpsInfoAvailable => 'No GPS info available…';

  @override
  String get gpsInfoButton_timestamp => 'Временная метка';

  @override
  String get gpsInfoButton_speed => 'Скорость';

  @override
  String get gpsInfoButton_heading => 'Heading';

  @override
  String get gpsInfoButton_accuracy => 'Точность';

  @override
  String get gpsInfoButton_altitude => 'Высота';

  @override
  String get gpsInfoButton_latitude => 'Широта';

  @override
  String get gpsInfoButton_copyLatitudeToClipboard =>
      'Copy latitude to clipboard.';

  @override
  String get gpsInfoButton_longitude => 'Долгота';

  @override
  String get gpsInfoButton_copyLongitudeToClipboard =>
      'Copy longitude to clipboard.';

  @override
  String get gpsLogButton_stopLogging => 'Stop Logging?';

  @override
  String get gpsLogButton_stopLoggingAndCloseLog =>
      'Stop logging and close the current GPS log?';

  @override
  String get gpsLogButton_newLog => 'New Log';

  @override
  String get gpsLogButton_enterNameForNewLog => 'Enter a name for the new log';

  @override
  String get gpsLogButton_couldNotStartLogging => 'Could not start logging: ';

  @override
  String get imageWidgets_loadingImage => 'Загрузка изображения…';

  @override
  String get logList_gpsLogsList => 'GPS Logs list';

  @override
  String get logList_selectAll => 'Выбрать все';

  @override
  String get logList_unSelectAll => 'Unselect all';

  @override
  String get logList_invertSelection => 'Invert selection';

  @override
  String get logList_mergeSelected => 'Merge selected';

  @override
  String get logList_loadingLogs => 'Loading logs…';

  @override
  String get logList_zoomTo => 'Zoom to';

  @override
  String get logList_properties => 'Свойства';

  @override
  String get logList_profileView => 'Просмотр профиля';

  @override
  String get logList_toGPX => 'В GPX';

  @override
  String get logList_gpsSavedInExportFolder => 'GPX saved in export folder.';

  @override
  String get logList_errorOccurredExportingLogGPX =>
      'Could not export log to GPX.';

  @override
  String get logList_delete => 'Удалить';

  @override
  String get logList_DELETE => 'Удалить';

  @override
  String get logList_areYouSureDeleteTheLog => 'Delete the log?';

  @override
  String get logList_hours => 'hours';

  @override
  String get logList_hour => 'час';

  @override
  String get logList_minutes => 'мин';

  @override
  String get logProperties_gpsLogProperties => 'GPS Log Properties';

  @override
  String get logProperties_logName => 'Log Name';

  @override
  String get logProperties_start => 'Start';

  @override
  String get logProperties_end => 'End';

  @override
  String get logProperties_duration => 'Продолжительность';

  @override
  String get logProperties_color => 'Цвет';

  @override
  String get logProperties_palette => 'Палитра';

  @override
  String get logProperties_width => 'Width';

  @override
  String get logProperties_distanceAtPosition => 'Distance at position:';

  @override
  String get logProperties_totalDistance => 'Общее расстояние:';

  @override
  String get logProperties_gpsLogView => 'GPS Log View';

  @override
  String get logProperties_disableStats => 'Turn off stats';

  @override
  String get logProperties_enableStats => 'Turn on stats';

  @override
  String get logProperties_totalDuration => 'Общая продолжительность:';

  @override
  String get logProperties_timestamp => 'Временная метка:';

  @override
  String get logProperties_durationAtPosition => 'Duration at position:';

  @override
  String get logProperties_speed => 'Скорость:';

  @override
  String get logProperties_elevation => 'Elevation:';

  @override
  String get logCompare_title => 'Log compare';

  @override
  String get logCompare_log1 => 'Log 1';

  @override
  String get logCompare_log2 => 'Log 2';

  @override
  String get logCompare_chartTab => 'Chart';

  @override
  String get logCompare_selectLog => 'Select log';

  @override
  String get logCompare_selectProject => 'Select project';

  @override
  String get logCompare_backToProjects => 'Back to projects';

  @override
  String get logCompare_filterLogs => 'Filter logs...';

  @override
  String get logCompare_filterProjects => 'Filter projects...';

  @override
  String get logCompare_clearFilter => 'Clear filter';

  @override
  String get logCompare_noProjects => 'No projects';

  @override
  String get logCompare_selectProjectFirst => 'Select a project';

  @override
  String get logCompare_noLogsOrLoading => 'No logs (or still loading)';

  @override
  String get logCompare_noLogsMatchFilter => 'No logs match the filter';

  @override
  String logCompare_logWithId(Object id) {
    return 'Log $id';
  }

  @override
  String logCompare_idWithValue(Object id) {
    return 'id: $id';
  }

  @override
  String get logCompare_selectAtLeastOneLog => 'Select at least one log';

  @override
  String get logCompare_vs => 'vs.';

  @override
  String get logCompare_xAxis => 'X';

  @override
  String get logCompare_yAxis => 'Y';

  @override
  String get logCompare_distance => 'Distance';

  @override
  String get logCompare_time => 'Time';

  @override
  String get logCompare_altitude => 'Altitude';

  @override
  String get logCompare_speed => 'Speed';

  @override
  String get logCompare_noChartableData =>
      'No chartable data in the selected logs.';

  @override
  String get logCompare_timeAxisTitle => 'Time [hh:mm]';

  @override
  String get logCompare_distanceAxisTitle => 'Distance [m]';

  @override
  String get logCompare_speedAxisTitle => 'Speed [m/s]';

  @override
  String get logCompare_altitudeAxisTitle => 'Altitude [m]';

  @override
  String get logCompare_raw => 'Raw';

  @override
  String get logCompare_smoothed => 'Smoothed';

  @override
  String get logCompare_zoomIn => 'Zoom in';

  @override
  String get logCompare_zoomOut => 'Zoom out';

  @override
  String get logCompare_resetZoom => 'Reset zoom';

  @override
  String get logCompare_panUp => 'Pan up';

  @override
  String get logCompare_panLeft => 'Pan left';

  @override
  String get logCompare_panRight => 'Pan right';

  @override
  String get logCompare_panDown => 'Pan down';

  @override
  String get noteList_simpleNotesList => 'Simple List of Notes';

  @override
  String get noteList_formNotesList => 'List of Form Notes';

  @override
  String get noteList_loadingNotes => 'Загрузка заметок…';

  @override
  String get noteList_zoomTo => 'Zoom to';

  @override
  String get noteList_edit => '\'Редактировать\'';

  @override
  String get noteList_properties => 'Свойства';

  @override
  String get noteList_delete => 'Удалить';

  @override
  String get noteList_DELETE => 'Удалить';

  @override
  String get noteList_areYouSureDeleteNote => 'Delete the note?';

  @override
  String get settings_settings => 'Настройки';

  @override
  String get settings_camera => 'Камера';

  @override
  String get settings_cameraResolution => 'Разрешение камеры';

  @override
  String get settings_resolution => 'Разрешение';

  @override
  String get settings_theCameraResolution => 'The camera resolution';

  @override
  String get settings_screen => 'Экран';

  @override
  String get settings_screenScaleBarIconSize =>
      'Screen, Scalebar and Icon Size';

  @override
  String get settings_keepScreenOn => 'Keep Screen On';

  @override
  String get settings_retinaScreenMode => 'HiDPI screen-mode';

  @override
  String get settings_toApplySettingEnterExitLayerView =>
      'Enter and exit the layer view to apply this setting.';

  @override
  String get settings_colorPickerToUse => 'Color Picker to use';

  @override
  String get settings_mapCenterCross => 'Map Center Cross';

  @override
  String get settings_color => 'Цвет';

  @override
  String get settings_size => 'Размер';

  @override
  String get settings_width => 'Width';

  @override
  String get settings_mapToolsIconSize => 'Icon Size for Map Tools';

  @override
  String get settings_gps => 'GPS';

  @override
  String get settings_gpsFiltersAndMockLoc => 'GPS filters and mock locations';

  @override
  String get settings_livePreview => 'Live Preview';

  @override
  String get settings_noPointAvailableYet => 'No point available yet.';

  @override
  String get settings_longitudeDeg => 'longitude [deg]';

  @override
  String get settings_latitudeDeg => 'latitude [deg]';

  @override
  String get settings_accuracyM => 'accuracy [m]';

  @override
  String get settings_altitudeM => 'altitude [m]';

  @override
  String get settings_headingDeg => 'heading [deg]';

  @override
  String get settings_speedMS => 'speed [m/s]';

  @override
  String get settings_isLogging => 'is logging?';

  @override
  String get settings_mockLocations => 'mock locations?';

  @override
  String get settings_minDistFilterBlocks => 'Min dist filter blocks';

  @override
  String get settings_minDistFilterPasses => 'Min dist filter passes';

  @override
  String get settings_minTimeFilterBlocks => 'Min time filter blocks';

  @override
  String get settings_minTimeFilterPasses => 'Min time filter passes';

  @override
  String get settings_hasBeenBlocked => 'Has been blocked';

  @override
  String get settings_distanceFromPrevM => 'Distance from prev [m]';

  @override
  String get settings_timeFromPrevS => 'Time since prev [s]';

  @override
  String get settings_locationInfo => 'Location Info';

  @override
  String get settings_filters => 'Фильтры';

  @override
  String get settings_disableFilters => 'Turn off Filters.';

  @override
  String get settings_enableFilters => 'Turn on Filters.';

  @override
  String get settings_zoomIn => 'Zoom in';

  @override
  String get settings_zoomOut => 'Zoom out';

  @override
  String get settings_activatePointFlow => 'Activate point flow.';

  @override
  String get settings_pausePointsFlow => 'Pause points flow.';

  @override
  String get settings_visualizePointCount => 'Visualize point count';

  @override
  String get settings_showGpsPointsValidPoints =>
      'Show the GPS points count for VALID points.';

  @override
  String get settings_showGpsPointsAllPoints =>
      'Show the GPS points count for ALL points.';

  @override
  String get settings_logFilters => 'Log filters';

  @override
  String get settings_minDistanceBetween2Points =>
      'Min distance between 2 points.';

  @override
  String get settings_minTimespanBetween2Points =>
      'Min timespan between 2 points.';

  @override
  String get settings_gpsFilter => 'GPS Filter';

  @override
  String get settings_disable => 'Turn off';

  @override
  String get settings_enable => 'Turn on';

  @override
  String get settings_theUseOfTheGps => 'the use of filtered GPS.';

  @override
  String get settings_warningThisWillAffectGpsPosition =>
      'Warning: This will affect GPS position, notes insertion, log statistics and charting.';

  @override
  String get settings_MockLocations => 'Mock locations';

  @override
  String get settings_testGpsLogDemoUse => 'test GPS log for demo use.';

  @override
  String get settings_setDurationGpsPointsInMilli =>
      'Set duration for GPS points in milliseconds.';

  @override
  String get settings_SETTING => 'Setting';

  @override
  String get settings_setMockedGpsDuration => 'Set Mocked GPS duration';

  @override
  String get settings_theValueHasToBeInt =>
      'The value has to be a whole number.';

  @override
  String get settings_milliseconds => 'миллисекунды';

  @override
  String get settings_useGoogleToImproveLoc =>
      'Use Google Services to improve location';

  @override
  String get settings_useOfGoogleServicesRestart =>
      'use of Google services (app restart needed).';

  @override
  String get settings_gpsLogsViewMode => 'GPS Logs view mode';

  @override
  String get settings_logViewModeForOrigData =>
      'Log view mode for original data.';

  @override
  String get settings_logViewModeFilteredData =>
      'Log view mode for filtered data.';

  @override
  String get settings_cancel => 'Отмена';

  @override
  String get settings_ok => 'ОК';

  @override
  String get settings_notesViewModes => 'Notes view modes';

  @override
  String get settings_selectNotesViewMode => 'Select a mode to view notes in.';

  @override
  String get settings_mapPlugins => 'Map Plugins';

  @override
  String get settings_vectorLayers => 'Vector Layers';

  @override
  String get settings_loadingOptionsInfoTool => 'Loading Options and Info Tool';

  @override
  String get settings_dataLoading => 'Data loading';

  @override
  String get settings_maxNumberFeatures => 'Max number of features.';

  @override
  String get settings_maxNumFeaturesPerLayer =>
      'Max features per layer. Remove and add the layer to apply.';

  @override
  String get settings_all => 'all';

  @override
  String get settings_loadMapArea => 'Load map area.';

  @override
  String get settings_loadOnlyLastVisibleArea =>
      'Load only on the last visible map area. Remove and add the layer again to apply.';

  @override
  String get settings_infoTool => 'Info Tool';

  @override
  String get settings_tapSizeInfoToolPixels =>
      'Tap size of the info tool in pixels.';

  @override
  String get settings_editingTool => 'Editing tool';

  @override
  String get settings_editingDragIconSize => 'Editing drag handler icon size.';

  @override
  String get settings_editingIntermediateDragIconSize =>
      'Editing intermediate drag handler icon size.';

  @override
  String get settings_diagnostics => 'Диагностика';

  @override
  String get settings_diagnosticsDebugLog => 'Diagnostics and Debug Log';

  @override
  String get settings_openFullDebugLog => 'Open full debug log';

  @override
  String get settings_debugLogView => 'Debug Log View';

  @override
  String get settings_viewAllMessages => 'View all messages';

  @override
  String get settings_viewOnlyErrorsWarnings => 'View only errors and warnings';

  @override
  String get settings_clearDebugLog => 'Clear debug log';

  @override
  String get settings_loadingData => 'Loading data…';

  @override
  String get settings_device => 'Устройство';

  @override
  String get settings_deviceIdentifier => 'Device identifier';

  @override
  String get settings_deviceId => 'Device ID';

  @override
  String get settings_overrideDeviceId => 'Override Device ID';

  @override
  String get settings_overrideId => 'Override ID';

  @override
  String get settings_pleaseEnterValidPassword =>
      'Please enter a valid server password.';

  @override
  String get settings_gss => 'GSS';

  @override
  String get settings_geopaparazziSurveyServer => 'Geopaparazzi Survey Server';

  @override
  String get settings_serverUrl => 'Server URL';

  @override
  String get settings_serverUrlStartWithHttp =>
      'The server URL needs to start with HTTP or HTTPS.';

  @override
  String get settings_serverPassword => 'Server Password';

  @override
  String get settings_allowSelfSignedCert => 'Allow self signed certificates';

  @override
  String get toolbarTools_zoomOut => 'Zoom out';

  @override
  String get toolbarTools_zoomIn => 'Zoom in';

  @override
  String get toolbarTools_cancelCurrentEdit => 'Cancel current edit.';

  @override
  String get toolbarTools_saveCurrentEdit => 'Save current edit.';

  @override
  String get toolbarTools_insertPointMapCenter => 'Insert point in map center.';

  @override
  String get toolbarTools_insertPointGpsPos => 'Insert point in GPS position.';

  @override
  String get toolbarTools_removeSelectedFeature => 'Remove selected feature.';

  @override
  String get toolbarTools_showFeatureAttributes => 'Show feature attributes.';

  @override
  String get toolbarTools_featureDoesNotHavePrimaryKey =>
      'The feature does not have a primary key. Editing is not allowed.';

  @override
  String get toolbarTools_queryFeaturesVectorLayers =>
      'Query features from loaded vector layers.';

  @override
  String get toolbarTools_measureDistanceWithFinger =>
      'Measure distances on the map with your finger.';

  @override
  String get toolbarTools_modifyGeomVectorLayers =>
      'Modify the geometry of editable vector layers.';

  @override
  String get coachMarks_singleTap => 'Single tap: ';

  @override
  String get coachMarks_longTap => 'Long tap: ';

  @override
  String get coachMarks_doubleTap => 'Double tap: ';

  @override
  String get coachMarks_simpleNoteButton => 'Simple Notes Button';

  @override
  String get coachMarks_addNewNote => 'add a new note';

  @override
  String get coachMarks_viewNotesList => 'view list of notes';

  @override
  String get coachMarks_viewNotesSettings => 'view settings for notes';

  @override
  String get coachMarks_formNotesButton => 'Form Notes Button';

  @override
  String get coachMarks_addNewFormNote => 'add new form note';

  @override
  String get coachMarks_viewFormNoteList => 'view list of form notes';

  @override
  String get coachMarks_gpsLogButton => 'GPS Log Button';

  @override
  String get coachMarks_startStopLogging => 'start logging/stop logging';

  @override
  String get coachMarks_viewLogsList => 'view list of logs';

  @override
  String get coachMarks_viewLogsSettings => 'view log settings';

  @override
  String get coachMarks_gpsInfoButton => 'GPS Info Button (if applicable)';

  @override
  String get coachMarks_centerMapOnGpsPos => 'center map on GPS position';

  @override
  String get coachMarks_showGpsInfo => 'show GPS info';

  @override
  String get coachMarks_toggleAutoCenterGps => 'toggle automatic center on GPS';

  @override
  String get coachMarks_layersViewButton => 'Layers View Button';

  @override
  String get coachMarks_openLayersView => 'Open the layers view';

  @override
  String get coachMarks_openLayersPluginDialog =>
      'Open the layer plugins dialog';

  @override
  String get coachMarks_zoomInButton => 'Zoom-in Button';

  @override
  String get coachMarks_zoomImMapOneLevel => 'Zoom in the map by one level';

  @override
  String get coachMarks_zoomOutButton => 'Zoom-out Button';

  @override
  String get coachMarks_zoomOutMapOneLevel => 'Zoom out the map by one level';

  @override
  String get coachMarks_bottomToolsButton => 'Bottom Tools Button';

  @override
  String get coachMarks_toggleBottomToolsBar => 'Toggle bottom tools bar';

  @override
  String get coachMarks_toolsButton => 'Tools Button';

  @override
  String get coachMarks_openEndDrawerToAccessProject =>
      'Open the end drawer to access project info and sharing options as well as map plugins, feature tools and extras';

  @override
  String get coachMarks_interactiveCoackMarksButton =>
      'Interactive coach-marks button';

  @override
  String get coachMarks_openInteractiveCoachMarks =>
      'Open the interactice coach marks explaining all the actions of the main map view.';

  @override
  String get coachMarks_mainMenuButton => 'Main-menu Button';

  @override
  String get coachMarks_openDrawerToLoadProject =>
      'Open the drawer to load or create a project, import and export data, sync with servers, access settings and exit the app/turn off the GPS.';

  @override
  String get coachMarks_skip => 'Пропустить';

  @override
  String get network_cancelledByUser => 'Cancelled by user.';

  @override
  String get network_completed => 'Завершено.';

  @override
  String get network_buildingBaseCachePerformance =>
      'Building base cache for improved performance (might take a while)…';

  @override
  String get network_thisFIleAlreadyBeingDownloaded =>
      'This file is already being downloaded.';

  @override
  String get network_download => 'Download';

  @override
  String get network_downloadFile => 'Download file';

  @override
  String get network_toTheDeviceTakeTime =>
      'to the device? This can take a while.';

  @override
  String get network_availableMaps => 'Available maps';

  @override
  String get network_searchMapByName => 'Search map by name';

  @override
  String get network_uploading => 'Uploading…';

  @override
  String get network_pleaseWait => 'please wait…';

  @override
  String get network_permissionOnServerDenied => 'Permission on server denied.';

  @override
  String get network_couldNotConnectToServer =>
      'Could not connect to the server. Is it online? Check your address.';

  @override
  String get form_smash_cantSaveImageDb => 'Could not save image in database.';

  @override
  String get formbuilder => 'Form builder';

  @override
  String get layersView_selectGssLayers => 'Select GSS Layers';

  @override
  String get layersView_noGssLayersFound => 'No GSS layers found.';

  @override
  String get layersView_noGssLayersAvailable =>
      'No layers available (loaded ones are not shown).';

  @override
  String get layersView_selectGssLayersToLoad => 'Select GSS layers to load.';

  @override
  String get layersView_unableToLoadGssLayers => 'Unable to load:';

  @override
  String get layersView_layerExists => 'Layer exists';

  @override
  String get layersView_layerAlreadyExists =>
      'Layer already exists, do you want to overwrite it?';

  @override
  String get gss_layerview_upload_changes => 'Upload changes';

  @override
  String get allGpsPointsCount => 'Gps points';

  @override
  String get filteredGpsPointsCount => 'Filtered points';

  @override
  String get addTmsFromDefaults => 'Add TMS from defaults';

  @override
  String get form_smash_noCameraDesktop =>
      'No camera option available on desktop.';

  @override
  String get settings_BottombarCustomization => 'Bottombar Customization';

  @override
  String get settings_Bottombar_showAddNote => 'Show the ADD NOTE button';

  @override
  String get settings_Bottombar_showAddFormNote =>
      'Show the ADD FORM NOTE button';

  @override
  String get settings_Bottombar_showAddGpsLog => 'Show the ADD GPS LOG button';

  @override
  String get settings_Bottombar_showGpsButton => 'Show the gps button';

  @override
  String get settings_Bottombar_showLayers => 'Show the layers button';

  @override
  String get settings_Bottombar_showZoom => 'Show the zoom buttons';

  @override
  String get settings_Bottombar_showEditing => 'Show the editing button';

  @override
  String get gss_layerview_filter => 'Filter';
}
