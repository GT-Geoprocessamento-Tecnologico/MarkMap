/*
 * Copyright (c) 2019-2026. Antonello Andrea (https://g-ant.eu). All rights reserved.
 * Use of this source code is governed by a GPL3 license that can be
 * found in the LICENSE file.
 */
/// do not format this

/// To get them in vim, first copy the page over and then:
///
/// g/DIR/d                  --> remove folders
/// %s/^.\{0,6\}//           --> remove leading brackets
/// %s/\t.*//                --> remove all but the name
/// :%s/^.*.map/['europe\/&', '$BASEPATH\/europe\/&'],/

const BASEPATH =
    "http://ftp-stud.hs-esslingen.de/pub/Mirrors/download.mapsforge.org/maps/v5/";
const List<List<String>> MAPLINKS = [
  /// EUROPE
  ['europe/albania.map', '$BASEPATH/europe/albania.map'],
  ['europe/alps.map', '$BASEPATH/europe/alps.map'],
  ['europe/andorra.map', '$BASEPATH/europe/andorra.map'],
  ['europe/austria.map', '$BASEPATH/europe/austria.map'],
  ['europe/azores.map', '$BASEPATH/europe/azores.map'],
  ['europe/belarus.map', '$BASEPATH/europe/belarus.map'],
  ['europe/belgium.map', '$BASEPATH/europe/belgium.map'],
  ['europe/bosnia-herzegovina.map', '$BASEPATH/europe/bosnia-herzegovina.map'],
  ['europe/bulgaria.map', '$BASEPATH/europe/bulgaria.map'],
  ['europe/croatia.map', '$BASEPATH/europe/croatia.map'],
  ['europe/cyprus.map', '$BASEPATH/europe/cyprus.map'],
  ['europe/czech-republic.map', '$BASEPATH/europe/czech-republic.map'],
  ['europe/denmark.map', '$BASEPATH/europe/denmark.map'],
  ['europe/estonia.map', '$BASEPATH/europe/estonia.map'],
  ['europe/faroe-islands.map', '$BASEPATH/europe/faroe-islands.map'],
  ['europe/finland.map', '$BASEPATH/europe/finland.map'],
  ['europe/france.map', '$BASEPATH/europe/france.map'],
  ['europe/georgia.map', '$BASEPATH/europe/georgia.map'],
  ['europe/germany.map', '$BASEPATH/europe/germany.map'],
  ['europe/great-britain.map', '$BASEPATH/europe/great-britain.map'],
  ['europe/greece.map', '$BASEPATH/europe/greece.map'],
  ['europe/hungary.map', '$BASEPATH/europe/hungary.map'],
  ['europe/iceland.map', '$BASEPATH/europe/iceland.map'],
  [
    'europe/ireland-and-northern-ireland.map',
    '$BASEPATH/europe/ireland-and-northern-ireland.map'
  ],
  ['europe/isle-of-man.map', '$BASEPATH/europe/isle-of-man.map'],
  ['europe/italy.map', '$BASEPATH/europe/italy.map'],
  ['europe/kosovo.map', '$BASEPATH/europe/kosovo.map'],
  ['europe/latvia.map', '$BASEPATH/europe/latvia.map'],
  ['europe/liechtenstein.map', '$BASEPATH/europe/liechtenstein.map'],
  ['europe/lithuania.map', '$BASEPATH/europe/lithuania.map'],
  ['europe/luxembourg.map', '$BASEPATH/europe/luxembourg.map'],
  ['europe/macedonia.map', '$BASEPATH/europe/macedonia.map'],
  ['europe/malta.map', '$BASEPATH/europe/malta.map'],
  ['europe/moldova.map', '$BASEPATH/europe/moldova.map'],
  ['europe/monaco.map', '$BASEPATH/europe/monaco.map'],
  ['europe/montenegro.map', '$BASEPATH/europe/montenegro.map'],
  ['europe/netherlands.map', '$BASEPATH/europe/netherlands.map'],
  ['europe/norway.map', '$BASEPATH/europe/norway.map'],
  ['europe/poland.map', '$BASEPATH/europe/poland.map'],
  ['europe/portugal.map', '$BASEPATH/europe/portugal.map'],
  ['europe/romania.map', '$BASEPATH/europe/romania.map'],
  ['europe/serbia.map', '$BASEPATH/europe/serbia.map'],
  ['europe/slovakia.map', '$BASEPATH/europe/slovakia.map'],
  ['europe/slovenia.map', '$BASEPATH/europe/slovenia.map'],
  ['europe/spain.map', '$BASEPATH/europe/spain.map'],
  ['europe/sweden.map', '$BASEPATH/europe/sweden.map'],
  ['europe/switzerland.map', '$BASEPATH/europe/switzerland.map'],
  ['europe/turkey.map', '$BASEPATH/europe/turkey.map'],
  ['europe/ukraine.map', '$BASEPATH/europe/ukraine.map'],

  /// ASIA
  ['asia/afghanistan.map', '$BASEPATH/asia/afghanistan.map'],
  ['asia/armenia.map', '$BASEPATH/asia/armenia.map'],
  ['asia/azerbaijan.map', '$BASEPATH/asia/azerbaijan.map'],
  ['asia/bangladesh.map', '$BASEPATH/asia/bangladesh.map'],
  ['asia/bhutan.map', '$BASEPATH/asia/bhutan.map'],
  ['asia/cambodia.map', '$BASEPATH/asia/cambodia.map'],
  ['asia/china.map', '$BASEPATH/asia/china.map'],
  ['asia/gcc-states.map', '$BASEPATH/asia/gcc-states.map'],
  ['asia/india.map', '$BASEPATH/asia/india.map'],
  ['asia/indonesia.map', '$BASEPATH/asia/indonesia.map'],
  ['asia/iran.map', '$BASEPATH/asia/iran.map'],
  ['asia/iraq.map', '$BASEPATH/asia/iraq.map'],
  ['asia/israel-and-palestine.map', '$BASEPATH/asia/israel-and-palestine.map'],
  ['asia/japan.map', '$BASEPATH/asia/japan.map'],
  ['asia/jordan.map', '$BASEPATH/asia/jordan.map'],
  ['asia/kazakhstan.map', '$BASEPATH/asia/kazakhstan.map'],
  ['asia/kyrgyzstan.map', '$BASEPATH/asia/kyrgyzstan.map'],
  ['asia/laos.map', '$BASEPATH/asia/laos.map'],
  ['asia/lebanon.map', '$BASEPATH/asia/lebanon.map'],
  [
    'asia/malaysia-singapore-brunei.map',
    '$BASEPATH/asia/malaysia-singapore-brunei.map'
  ],
  ['asia/maldives.map', '$BASEPATH/asia/maldives.map'],
  ['asia/mongolia.map', '$BASEPATH/asia/mongolia.map'],
  ['asia/myanmar.map', '$BASEPATH/asia/myanmar.map'],
  ['asia/nepal.map', '$BASEPATH/asia/nepal.map'],
  ['asia/north-korea.map', '$BASEPATH/asia/north-korea.map'],
  ['asia/pakistan.map', '$BASEPATH/asia/pakistan.map'],
  ['asia/philippines.map', '$BASEPATH/asia/philippines.map'],
  ['asia/south-korea.map', '$BASEPATH/asia/south-korea.map'],
  ['asia/sri-lanka.map', '$BASEPATH/asia/sri-lanka.map'],
  ['asia/syria.map', '$BASEPATH/asia/syria.map'],
  ['asia/taiwan.map', '$BASEPATH/asia/taiwan.map'],
  ['asia/tajikistan.map', '$BASEPATH/asia/tajikistan.map'],
  ['asia/thailand.map', '$BASEPATH/asia/thailand.map'],
  ['asia/turkmenistan.map', '$BASEPATH/asia/turkmenistan.map'],
  ['asia/uzbekistan.map', '$BASEPATH/asia/uzbekistan.map'],
  ['asia/vietnam.map', '$BASEPATH/asia/vietnam.map'],
  ['asia/yemen.map', '$BASEPATH/asia/yemen.map'],

  /// AFRICA
  ['africa/algeria.map', '$BASEPATH/africa/algeria.map'],
  ['africa/angola.map', '$BASEPATH/africa/angola.map'],
  ['africa/benin.map', '$BASEPATH/africa/benin.map'],
  ['africa/botswana.map', '$BASEPATH/africa/botswana.map'],
  ['africa/burkina-faso.map', '$BASEPATH/africa/burkina-faso.map'],
  ['africa/burundi.map', '$BASEPATH/africa/burundi.map'],
  ['africa/cameroon.map', '$BASEPATH/africa/cameroon.map'],
  ['africa/canary-islands.map', '$BASEPATH/africa/canary-islands.map'],
  ['africa/cape-verde.map', '$BASEPATH/africa/cape-verde.map'],
  [
    'africa/central-african-republic.map',
    '$BASEPATH/africa/central-african-republic.map'
  ],
  ['africa/chad.map', '$BASEPATH/africa/chad.map'],
  ['africa/comores.map', '$BASEPATH/africa/comores.map'],
  ['africa/congo-brazzaville.map', '$BASEPATH/africa/congo-brazzaville.map'],
  [
    'africa/congo-democratic-republic.map',
    '$BASEPATH/africa/congo-democratic-republic.map'
  ],
  ['africa/djibouti.map', '$BASEPATH/africa/djibouti.map'],
  ['africa/egypt.map', '$BASEPATH/africa/egypt.map'],
  ['africa/equatorial-guinea.map', '$BASEPATH/africa/equatorial-guinea.map'],
  ['africa/eritrea.map', '$BASEPATH/africa/eritrea.map'],
  ['africa/ethiopia.map', '$BASEPATH/africa/ethiopia.map'],
  ['africa/gabon.map', '$BASEPATH/africa/gabon.map'],
  ['africa/ghana.map', '$BASEPATH/africa/ghana.map'],
  ['africa/guinea-bissau.map', '$BASEPATH/africa/guinea-bissau.map'],
  ['africa/guinea.map', '$BASEPATH/africa/guinea.map'],
  ['africa/ivory-coast.map', '$BASEPATH/africa/ivory-coast.map'],
  ['africa/kenya.map', '$BASEPATH/africa/kenya.map'],
  ['africa/lesotho.map', '$BASEPATH/africa/lesotho.map'],
  ['africa/liberia.map', '$BASEPATH/africa/liberia.map'],
  ['africa/libya.map', '$BASEPATH/africa/libya.map'],
  ['africa/madagascar.map', '$BASEPATH/africa/madagascar.map'],
  ['africa/malawi.map', '$BASEPATH/africa/malawi.map'],
  ['africa/mali.map', '$BASEPATH/africa/mali.map'],
  ['africa/mauritania.map', '$BASEPATH/africa/mauritania.map'],
  ['africa/mauritius.map', '$BASEPATH/africa/mauritius.map'],
  ['africa/morocco.map', '$BASEPATH/africa/morocco.map'],
  ['africa/mozambique.map', '$BASEPATH/africa/mozambique.map'],
  ['africa/namibia.map', '$BASEPATH/africa/namibia.map'],
  ['africa/niger.map', '$BASEPATH/africa/niger.map'],
  ['africa/nigeria.map', '$BASEPATH/africa/nigeria.map'],
  ['africa/rwanda.map', '$BASEPATH/africa/rwanda.map'],
  [
    'africa/saint-helena-ascension-and-tristan-da-cunha.map',
    '$BASEPATH/africa/saint-helena-ascension-and-tristan-da-cunha.map'
  ],
  [
    'africa/sao-tome-and-principe.map',
    '$BASEPATH/africa/sao-tome-and-principe.map'
  ],
  ['africa/senegal-and-gambia.map', '$BASEPATH/africa/senegal-and-gambia.map'],
  ['africa/seychelles.map', '$BASEPATH/africa/seychelles.map'],
  ['africa/sierra-leone.map', '$BASEPATH/africa/sierra-leone.map'],
  ['africa/somalia.map', '$BASEPATH/africa/somalia.map'],
  [
    'africa/south-africa-and-lesotho.map',
    '$BASEPATH/africa/south-africa-and-lesotho.map'
  ],
  ['africa/south-sudan.map', '$BASEPATH/africa/south-sudan.map'],
  ['africa/sudan.map', '$BASEPATH/africa/sudan.map'],
  ['africa/swaziland.map', '$BASEPATH/africa/swaziland.map'],
  ['africa/tanzania.map', '$BASEPATH/africa/tanzania.map'],
  ['africa/togo.map', '$BASEPATH/africa/togo.map'],
  ['africa/tunisia.map', '$BASEPATH/africa/tunisia.map'],
  ['africa/uganda.map', '$BASEPATH/africa/uganda.map'],
  ['africa/zambia.map', '$BASEPATH/africa/zambia.map'],
  ['africa/zimbabwe.map', '$BASEPATH/africa/zimbabwe.map'],

  /// South America
  ['south-america/argentina.map', '$BASEPATH/south-america/argentina.map'],
  ['south-america/bolivia.map', '$BASEPATH/south-america/bolivia.map'],
  ['south-america/brazil.map', '$BASEPATH/south-america/brazil.map'],
  ['south-america/chile.map', '$BASEPATH/south-america/chile.map'],
  ['south-america/colombia.map', '$BASEPATH/south-america/colombia.map'],
  ['south-america/ecuador.map', '$BASEPATH/south-america/ecuador.map'],
  ['south-america/paraguay.map', '$BASEPATH/south-america/paraguay.map'],
  ['south-america/peru.map', '$BASEPATH/south-america/peru.map'],
  ['south-america/suriname.map', '$BASEPATH/south-america/suriname.map'],
  ['south-america/uruguay.map', '$BASEPATH/south-america/uruguay.map'],
  ['south-america/venezuela.map', '$BASEPATH/south-america/venezuela.map'],

  /// North America
  ['north-america/greenland.map', '$BASEPATH/north-america/greenland.map'],
  ['north-america/mexico.map', '$BASEPATH/north-america/mexico.map'],
  ['north-america/us-midwest.map', '$BASEPATH/north-america/us-midwest.map'],
  [
    'north-america/us-northeast.map',
    '$BASEPATH/north-america/us-northeast.map'
  ],
  ['north-america/us-pacific.map', '$BASEPATH/north-america/us-pacific.map'],
  ['north-america/us-south.map', '$BASEPATH/north-america/us-south.map'],
  ['north-america/us-west.map', '$BASEPATH/north-america/us-west.map'],

  /// Russia
  [
    'russia/central-fed-district.map',
    '$BASEPATH/russia/central-fed-district.map'
  ],
  [
    'russia/crimean-fed-district.map',
    '$BASEPATH/russia/crimean-fed-district.map'
  ],
  [
    'russia/north-caucasus-fed-district.map',
    '$BASEPATH/russia/north-caucasus-fed-district.map'
  ],
  [
    'russia/northwestern-fed-district.map',
    '$BASEPATH/russia/northwestern-fed-district.map'
  ],
  [
    'russia/siberian-fed-district.map',
    '$BASEPATH/russia/siberian-fed-district.map'
  ],
  ['russia/south-fed-district.map', '$BASEPATH/russia/south-fed-district.map'],
  ['russia/volga-fed-district.map', '$BASEPATH/russia/volga-fed-district.map'],

  /// Central America
  ['central-america/belize.map', '$BASEPATH/central-america/belize.map'],
  ['central-america/cuba.map', '$BASEPATH/central-america/cuba.map'],
  ['central-america/guatemala.map', '$BASEPATH/central-america/guatemala.map'],
  [
    'central-america/haiti-and-domrep.map',
    '$BASEPATH/central-america/haiti-and-domrep.map'
  ],
  ['central-america/jamaica.map', '$BASEPATH/central-america/jamaica.map'],
  ['central-america/nicaragua.map', '$BASEPATH/central-america/nicaragua.map'],

  /// Australia Oceania
  [
    'australia-oceania/australia.map',
    '$BASEPATH/australia-oceania/australia.map'
  ],
  ['australia-oceania/fiji.map', '$BASEPATH/australia-oceania/fiji.map'],
  [
    'australia-oceania/new-caledonia.map',
    '$BASEPATH/australia-oceania/new-caledonia.map'
  ],
  [
    'australia-oceania/new-zealand.map',
    '$BASEPATH/australia-oceania/new-zealand.map'
  ],
  [
    'australia-oceania/papua-new-guinea.map',
    '$BASEPATH/australia-oceania/papua-new-guinea.map'
  ],
];
