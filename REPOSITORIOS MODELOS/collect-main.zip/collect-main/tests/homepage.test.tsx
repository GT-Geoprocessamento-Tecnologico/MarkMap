// @vitest-environment jsdom
import { describe, it, expect, vi, afterEach, beforeEach } from "vitest";
import * as React from "react";
import {
  render,
  screen,
  fireEvent,
  waitFor,
  cleanup,
  act,
} from "@testing-library/react";
import { FlowDemo } from "../src/homepage/FlowDemo";
import { AttentionDemo } from "../src/homepage/AttentionDemo";
import { PackageBrowser } from "../src/homepage/PackageBrowser";
import { PreviewForm } from "../src/homepage/PreviewForm";
import { HomepageApp } from "../src/homepage/HomepageApp";
import { ATTENTION_CHECKS } from "../src/data/attentionChecks";

const storageEmpty = () => {
  if (globalThis.localStorage) expect(globalThis.localStorage.length).toBe(0);
  if (globalThis.sessionStorage)
    expect(globalThis.sessionStorage.length).toBe(0);
};

beforeEach(() => {
  // The preview form only renders when the Supabase project is configured.
  // It must never fall back to a hardcoded production project, so the tests
  // provide an explicit local configuration.
  vi.stubEnv("VITE_SUPABASE_URL", "https://test-project.supabase.co");
  vi.stubEnv("VITE_SUPABASE_PUBLISHABLE_KEY", "sb_publishable_test_key");
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
  if (globalThis.localStorage) globalThis.localStorage.clear();
  if (globalThis.sessionStorage) globalThis.sessionStorage.clear();
});

/**
 * The homepage demo must mirror the app's real frontend: the FlowDemo mounts
 * the real Collector/ContributorHome, uses the real schema fixture and the
 * real attention bank, and records nothing anywhere.
 */

describe("FlowDemo — real app frontend inside the iPhone mock-up", () => {
  it("renders the real Field Home with the app's own copy", () => {
    render(<FlowDemo />);
    // The real flow opens on the authentic field home screen with project intro and add observation action.
    expect(screen.getByText("Fieldwork")).toBeTruthy();
    expect(screen.getByText("Example Survey")).toBeTruthy();
    expect(
      screen.getByRole("button", { name: /add observation/i }),
    ).toBeTruthy();
    // The iPhone chrome is present.
    expect(document.querySelector(".hp-iphone-screen")).toBeTruthy();
    expect(document.querySelector(".hp-dynamic-island")).toBeTruthy();
  });

  it("runs the full flow on the real home screen, syncs to Sent, and records nothing", async () => {
    render(<FlowDemo />);
    // Start from the authentic Field Home by tapping Add observation
    fireEvent.click(screen.getByRole("button", { name: /add observation/i }));
    const viewport = () => document.querySelector(".hp-app-viewport")!;

    const stepTitle = () =>
      viewport().querySelector(".step-title")?.textContent?.trim() ?? "";
    const primaryButton = () =>
      screen.queryByRole("button", { name: /continue|skip|save observation/i });
    const homeReached = () =>
      screen.queryByRole("button", { name: /add observation/i }) !== null;
    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

    // Advance through every step. Single answers auto-advance (~220 ms);
    // multi-select and optional steps need the primary button, so if the
    // title has not changed after an answer, press Continue/Skip. Save on
    // the last step (attention may be last and required — answer it first).
    for (let guard = 0; guard < 26; guard++) {
      await waitFor(() => expect(stepTitle()).not.toBe(""));
      const title = stepTitle();

      if (title === "Site code") {
        const input = viewport().querySelector("input");
        fireEvent.change(input!, { target: { value: "VA-023" } });
        await waitFor(() =>
          expect(primaryButton()).toHaveProperty("disabled", false),
        );
        fireEvent.click(primaryButton()!);
      } else if (title === "Date observed") {
        const input = viewport().querySelector('input[type="date"]');
        fireEvent.change(input!, { target: { value: "2026-08-10" } });
      } else {
        // Covers single/tri-state/attention steps (auto-advance) as well
        // as the attention step whose title is the check prompt itself.
        const option = viewport().querySelector(
          ".choice-button, .tri-state button",
        );
        if (option) {
          fireEvent.click(option);
        } else {
          fireEvent.click(primaryButton()!);
        }
      }

      await act(async () => {
        await sleep(360);
      });
      const primary = primaryButton();
      // Save is only clickable once the (required) last step is answered.
      if (
        primary &&
        !primary.disabled &&
        /save observation/i.test(primary.textContent ?? "")
      ) {
        await act(async () => {
          fireEvent.click(primary);
        });
        break;
      }
      // Multi-select and required-last steps (e.g. attention) stay put:
      // press the primary action so the walk continues to the next step.
      if (stepTitle() === title) {
        const current = primaryButton();
        if (current && !current.disabled) {
          await act(async () => {
            fireEvent.click(current);
          });
        }
        await act(async () => {
          await sleep(360);
        });
        if (homeReached()) break;
        const after = primaryButton();
        if (
          after &&
          !after.disabled &&
          /save observation/i.test(after.textContent ?? "")
        ) {
          await act(async () => {
            fireEvent.click(after);
          });
          break;
        }
      }
      if (homeReached()) break;
    }

    // The real ContributorHome appears after save.
    await waitFor(() => expect(homeReached()).toBe(true));
    expect(screen.getByText("Example Survey")).toBeTruthy();
    expect(screen.getByText(/Saved here/i)).toBeTruthy();

    // The demo never persists anything: no storage, no IndexedDB.
    storageEmpty();
    const databases = await indexedDB.databases();
    expect(
      databases.filter((db) => (db.name ?? "").startsWith("collect-local")),
    ).toEqual([]);

    // Background sync simulation completes on the real home screen.
    await waitFor(
      () =>
        expect(screen.getAllByText("Sent").length).toBeGreaterThanOrEqual(1),
      { timeout: 8000 },
    );
    storageEmpty();
  }, 15000);
});

describe("AttentionDemo — real bank and real strip logic", () => {
  it("uses a prompt from the app's own attention bank", () => {
    render(<AttentionDemo />);
    const prompts = ATTENTION_CHECKS.map((check) => check.prompt);
    const heading = screen.getByRole("heading", { level: 3 });
    expect(prompts).toContain(heading.textContent);
    expect(screen.getAllByRole("button", { name: /./ }).length).toBe(4);
  });

  it("shows the stored audit record and reliability score after answering", async () => {
    render(<AttentionDemo />);
    const options = screen.getAllByRole("button", { name: /./ });
    fireEvent.click(options[0]);
    await waitFor(() =>
      expect(screen.getByText(/audit record stored/i)).toBeTruthy(),
    );
    expect(screen.getByText(/check_key/i)).toBeTruthy();
    expect(screen.getByText(/reliability_score/i)).toBeTruthy();
    // The stored audit record must not contain the prompt question text anywhere.
    const code = document.querySelector("pre");
    expect(code).toBeTruthy();
    expect(code!.textContent).not.toContain("What is");
  });
});

describe("PackageBrowser — derived from the canonical demo dataset", () => {
  it("defaults to manifest.json and shows derived files", () => {
    render(<PackageBrowser />);
    expect(screen.getAllByText("manifest.json").length).toBeGreaterThanOrEqual(
      1,
    );
    expect(screen.getByText(/export_format_version/i)).toBeTruthy();

    fireEvent.click(screen.getByText("submissions.jsonl"));
    expect(screen.getByText(/VA-001/i)).toBeTruthy();

    fireEvent.click(screen.getByText("submissions.geojson"));
    expect(screen.getByText(/FeatureCollection/i)).toBeTruthy();

    fireEvent.click(screen.getByText("datacite.json"));
    expect(screen.getByText(/datacite.org\/schema\/kernel-4.4/i)).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: /^media\//i }));
    expect(screen.getByText(/never recompresses/i)).toBeTruthy();
  });
});

describe("PreviewForm — research preview email CTA", () => {
  it("validates the email before sending", async () => {
    render(<PreviewForm />);
    fireEvent.click(screen.getByRole("button", { name: /request access/i }));
    expect(screen.getByRole("alert")).toBeTruthy();
  });

  it("requires inquiry details before sending", async () => {
    render(<PreviewForm />);
    fireEvent.change(screen.getByLabelText(/work email/i), {
      target: { value: "researcher@lab.org" },
    });
    fireEvent.click(screen.getByRole("button", { name: /request access/i }));
    expect(screen.getByRole("alert")).toBeTruthy();
  });

  it("posts one row with the inquiry and shows the success state", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true });
    vi.stubGlobal("fetch", fetchMock);
    render(<PreviewForm />);

    fireEvent.change(screen.getByLabelText(/work email/i), {
      target: { value: "researcher@lab.org" },
    });
    fireEvent.change(screen.getByLabelText(/tell us about your project/i), {
      target: {
        value:
          "A building survey in a valley with patchy coverage, published as a dataset.",
      },
    });
    fireEvent.click(screen.getByRole("button", { name: /request access/i }));

    await waitFor(() =>
      expect(screen.getByText(/request received/i)).toBeTruthy(),
    );
    expect(fetchMock).toHaveBeenCalledTimes(1);
    // SAFETY: fetchMock receives [url, init] tuple.
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toContain("/rest/v1/preview_requests");
    const body = JSON.parse(String(init.body));
    expect(body.email).toBe("researcher@lab.org");
    expect(body.source).toBe("homepage");
    expect(body.use_case).toContain("patchy coverage");
    storageEmpty();
  });

  it("asks for more detail when the inquiry is too short", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true });
    vi.stubGlobal("fetch", fetchMock);
    render(<PreviewForm />);
    fireEvent.change(screen.getByLabelText(/work email/i), {
      target: { value: "researcher@lab.org" },
    });
    fireEvent.change(screen.getByLabelText(/tell us about your project/i), {
      target: { value: "hi" },
    });
    fireEvent.click(screen.getByRole("button", { name: /request access/i }));
    expect(screen.getByRole("alert")).toBeTruthy();
    expect(fetchMock).not.toHaveBeenCalled();
  });
});

describe("HomepageApp — promotional home with email CTA", () => {
  it("treats an RLS-rejected duplicate as already-listed", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({
        code: "42501",
        message: "new row violates row-level security policy",
      }),
    });
    vi.stubGlobal("fetch", fetchMock);
    render(<PreviewForm />);
    fireEvent.change(screen.getByLabelText(/work email/i), {
      target: { value: "dup@lab.org" },
    });
    fireEvent.change(screen.getByLabelText(/tell us about your project/i), {
      target: { value: "Research field campaign inquiring about access." },
    });
    fireEvent.click(screen.getByRole("button", { name: /request access/i }));
    await waitFor(() =>
      expect(screen.getByText(/already on the preview list/i)).toBeTruthy(),
    );
  });

  it("prefills the research-preview form from the hero capture", async () => {
    const { container } = render(<HomepageApp />);
    // SAFETY: querySelector returns hero input element.
    const heroInput = container.querySelector(
      ".hp-capture input",
    ) as HTMLInputElement;
    fireEvent.change(heroInput, { target: { value: "lead@lab.org" } });
    fireEvent.click(container.querySelector(".hp-capture button")!);
    // The research-preview form receives the hero email (scoped: the hero
    // capture also has an email input).
    // SAFETY: querySelector returns preview email input element.
    const formEmail = container.querySelector(
      '#preview input[type="email"]',
    ) as HTMLInputElement;
    await waitFor(() => expect(formEmail.value).toBe("lead@lab.org"));
    storageEmpty();
  });
});
