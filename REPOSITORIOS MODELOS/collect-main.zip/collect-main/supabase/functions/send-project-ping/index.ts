import { z } from "npm:zod@4.4.3";
import { corsHeaders, json, options, serve } from "../_shared/cors.ts";
import { errorMessage, projectAccess, requireUser } from "../_shared/auth.ts";
import { appEntryUrl } from "../_shared/config.ts";
import { sendEmail } from "../_shared/mail.ts";

const pingSchema = z.object({
  project_id: z.string().min(1),
  contributor_id: z.string().min(1),
});

serve(async (request) => {
  if (request.method === "OPTIONS") return options();
  if (request.method !== "POST") {
    return json(
      { error: "Method not allowed" },
      {
        status: 405,
        headers: corsHeaders,
      },
    );
  }
  try {
    const { user, service } = await requireUser(request);
    const rawJson = await request.json().catch(() => ({}));
    const parsed = pingSchema.safeParse(rawJson);
    if (!parsed.success) {
      return json(
        { error: "Project and contributor are required" },
        {
          status: 400,
        },
      );
    }
    const projectId = parsed.data.project_id;
    const contributorId = parsed.data.contributor_id;

    const access = await projectAccess(service, projectId, user.id);
    if (!access?.admin) {
      return json(
        { error: "Administrator access is required" },
        {
          status: 403,
        },
      );
    }

    const { data: membership } = await service
      .from("project_members")
      .select("user_id")
      .eq("project_id", projectId)
      .eq("user_id", contributorId)
      .maybeSingle();
    if (!membership) {
      return json(
        { error: "Contributor is not assigned to this project" },
        {
          status: 404,
        },
      );
    }
    const { data: contributor, error: contributorError } = await service.auth
      .admin.getUserById(contributorId);
    const email = contributor?.user?.email?.trim();
    if (contributorError || !email) {
      return json(
        { error: "Contributor email is unavailable" },
        {
          status: 409,
        },
      );
    }
    const { data: project } = await service
      .from("projects")
      .select("name")
      .eq("id", projectId)
      .maybeSingle();
    await sendEmail({
      to: email,
      subject: `${
        project?.name ?? "Your field project"
      } still has field data waiting to synchronize`,
      text: `${
        project?.name ?? "Your field project"
      } still has field data waiting to synchronize.\n\nOpen the collector when you have connectivity and allow synchronization to complete.\n\n${appEntryUrl()}?project=${
        encodeURIComponent(projectId)
      }`,
    });
    await service.from("audit_events").insert({
      organization_id: access.project.organization_id,
      project_id: projectId,
      actor_id: user.id,
      action: "contributor_pinged",
      metadata: { contributor_id: contributorId },
    });
    return json({ accepted: true });
  } catch (error) {
    if (error instanceof Response) return error;
    return json({ error: errorMessage(error) }, { status: 500 });
  }
});
